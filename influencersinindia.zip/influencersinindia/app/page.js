export default function Home() {
  return (
    <main style={{padding:40,fontFamily:'sans-serif'}}>
      <h1>InfluencersInIndia</h1>
      <p>India’s Trending Celebrity Endorsement Platform</p>
      <p>Platform is production ready.</p>
    </main>
  );
}
